function Header() {
    return (
      <header style={{ backgroundColor: 'navy', color: 'white', textAlign: 'center' }}>
           <h1 style={{fontWeight:'bold'}}>My Favorite Cities</h1>
      </header>
    );
  }
  export default Header;