function MainContent() {
    return (
      <main style={{backgroundColor:'lightgreen', textAlign: 'center', }}>
        <p style={{textAlign:'center', color:'black', fontFamily:'serif', fontWeight:'normal'}}>I love to visit New York, Paris, and Tokyo.</p>
      </main>
    )
  }
  export default MainContent;