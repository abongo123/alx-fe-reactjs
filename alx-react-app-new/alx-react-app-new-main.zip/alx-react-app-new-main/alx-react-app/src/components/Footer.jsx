export function Footer() {
  return (

<footer style={{backgroundColor: 'grey', color:'white', textAlign: 'left'}}>
  <p style={{fontFamily:'cursive', fontWeight:'revert'}}>© 2023 City Lovers</p>
</footer>
  )
}